
/* All configuration for SMG2000 is done in the Makefile */
