#!/bin/bash
#
###############################################################
#
# LiveCD customization script
# 
# Run this script on a SL Installation
# to prepare the system for a LiveCD 
#
# Urs Beyerle, PSI
#
###############################################################

### source livecd.conf
. livecd.conf

###############################################################

function usage() {

   ## Usage
   # ----------------------------------------------------------

   cat <<EOF

   Optional Options:

    -h:       print this screen
    -psi:     customize for PSI Live CD
    -dvd:     customize for Live DVD
    -mini:    customize for Mini Live CD

EOF

}

###############################################################

###############################################################
# Definitions
###############################################################

### read options from command-line
PSI=""
while [ $# -gt 0 ]; do

    case "$1" in
       -h)
            usage; exit;;
       -psi)
            PSI=-psi; shift; continue;;
       -dvd)
            DVD=-dvd; shift; continue;;
       -mini)
            MINI=-mini; shift; continue;;
       *)
            usage; exit;;
    esac

done

### arch x86_64 or i686 ?
ARCH=$( /bin/arch )
[ "$ARCH" != "x86_64" ] && ARCH=i686

### set local username for PSI
[ $PSI ] && LOCALUSER=l_psi



###############################################################
# Backup some original files
###############################################################

echo "Backup original files ..."

ori_files="/etc/init.d/netfs \
           /etc/init.d/autofs \
           /etc/init.d/halt \
           /etc/init.d/network
           /etc/init.d/functions \
           /etc/rc.d/rc.sysinit \
           /etc/sysconfig/afs \
           /etc/motd \
           /etc/redhat-release \
	   /etc/rc.d/rc.local \
           /etc/resolv.conf"

for file in $ori_files; do
    [ ! -e ${file}.ori ] && cp -a ${file} ${file}.ori 2>/dev/null
done



###############################################################
# Configure system
###############################################################

echo "Configure system ..."

# build nvidia kernel modules
[ -x /usr/sbin/mknvidia ] && mknvidia

# build vpnclient kernel module
[ -x /usr/sbin/mkvpnclient ] && mkvpnclient

# Update Virus definitions 
# run freshclam
if [ -x /usr/bin/freshclam ]; then
    echo; echo "Run /usr/bin/freshclam:"
    /etc/init.d/clamd status || /etc/init.d/clamd start && /usr/bin/freshclam
    /etc/init.d/clamd stop
    echo
fi
# update f-prot and uvscan
[ -x /usr/local/f-prot/tools/check-updates.pl ] && /usr/local/f-prot/tools/check-updates.pl
[ -x /usr/local/uvscan/update-dat ] && /usr/local/uvscan/update-dat

# run depmod -a for the LiveCD kernels
echo "Run depmod -a $KERNEL ..."; depmod -a $KERNEL
if [ $SMP ]; then
    echo "Run depmod -a ${KERNEL}smp ..."
    depmod -a ${KERNEL}smp
fi

# delete users (just to be sure)
userdel -r $LOCALUSER 2>/dev/null
userdel -r l_psi 2>/dev/null
userdel -r ossuser 2>/dev/null
userdel -r user 2>/dev/null

# move /opt to /usr/opt and link /opt -> /usr/opt
# (if not already yet done before)
if [ ! -L /opt ]; then
    echo "Move /opt to /usr/opt"
    mv /opt /usr/
    ln -s /usr/opt /opt
fi

# umount PSI master
[ $PSI ] && umount /mnt/master 2>/dev/null
    
# copy back /etc/yum.repos.d
if [ ! $PSI ]; then
    if [ -d /etc/yum.repos.d.ori ]; then
	cp -a /etc/yum.repos.d.ori /etc/yum.repos.d
    fi
fi

# run cfagent
if [ $PSI ]; then
    # cfagent needs running afs
    /etc/init.d/afs start
    echo "Run cfagent ..."
    cfagent
fi

echo "done."
echo "--------------------------------------------"



###############################################################
# Clean up and delete files
###############################################################

echo "Cleaning up ..."

### set LANG
export LANG=C

### stop AFS
/etc/init.d/afs stop 2>/dev/null

### clean up yum
yum clean all >/dev/null
rm -rf /var/cache/yum/*

### remove cfengine log files
rm -f /var/cfengine/*log

### delete log files
find /var/log/ -type f -exec rm -f {} \;

### clean rpm database
rm -rf /var/lib/rpm/__db.*

### clean /var/spool/mail
rm -rf /var/spool/mail/*
touch /var/spool/mail/root
chmod 600 /var/spool/mail/root

### delete .cfsaved Files
if [ $PSI ]; then
    echo -n "Delete .cfsaved Files, please wait: "
    find / -xdev -name "*\.cfsaved" -exec rm -f {} \;
    echo "ok."
fi

### delete .rpmori .rpm Files in /etc
find /etc -name "*\.rpmorig" -exec rm -f {} \;
find /etc -name "*\.rpmnew"  -exec rm -f {} \;
find /etc -name "*\.rpmsave" -exec rm -f {} \;

### delete *~ files in /etc
find /etc | grep "~$" | while read f; do rm -f "$f"; done

### clean up /root
rm -f /root/.bash_history
rm -f /root/.ssh/known_hosts

### clean AFS cache
if [ -d /usr/vice/cache ]; then
    rm -rf /usr/vice/cache
    mkdir /usr/vice/cache
fi
if [ -d /var/cache/openafs ]; then
    rm -rf /var/cache/openafs
    mkdir /var/cache/openafs
fi

### clean up /var/tmp
rm -rf /var/tmp/*

### remove root passwd
sed -i "s|^root:.*|root:\*:12943:0:99999:7:::|" /etc/shadow
sed -i "s|^root:.*:0:0|root:x:0:0|" /etc/passwd

### remove /.autofsck
rm -f /.autofsck

### disable cfagent
rm -f /etc/cron.d/cfengine

### disable check_update in rc.local.psi
[ $PSI ] && sed -i "s|/etc/init.d/check_update|# /etc/init.d/check_update|" /etc/rc.d/rc.local.psi

### create in /boot link to LiveCD kernel(s)
ln -fs /boot/vmlinuz-$KERNEL /boot/vmlinuz
[ $SMP ] && ln -fs /boot/vmlinuz-${KERNEL}smp /boot/vmlinuz${SMP}

### Files to remove
FILES_REMOVE="/etc/ssh/ssh_host_key \
              /etc/ssh/ssh_host_key.pub \
              /etc/ssh/ssh_host_rsa_key.pub \
              /etc/ssh/ssh_host_dsa_key \
              /etc/ssh/ssh_host_dsa_key.pub"
for file in $FILES_REMOVE; do
    rm -f $file
done

### remove useless cronjobs
mkdir -p /etc/cron_backup
mv /etc/cron.d/sysstat /etc/cron_backup/ 2>/dev/null
mv /etc/cron.daily/00-makewhatis.cron /etc/cron_backup/ 2>/dev/null
mv /etc/cron.weekly/00-makewhatis.cron /etc/cron_backup/00-makewhatis.cron.weekly 2>/dev/null
mv /etc/cron.daily/rpm /etc/cron_backup/ 2>/dev/null
mv /etc/cron.daily/slocate.cron /etc/cron_backup/ 2>/dev/null
mv /etc/cron.daily/tetex.cron /etc/cron_backup/ 2>/dev/null
mv /etc/cron.daily/yum.cron /etc/cron_backup/ 2>/dev/null
mv /etc/cron.daily/prelink /etc/cron_backup/ 2>/dev/null
mv /etc/cron.daily/00-logwatch /etc/cron_backup/ 2>/dev/null

### remove desktop entry from crossover
[ $PSI ] && rm -f "/usr/share/apps/kdesktop/DesktopLinks/Internet Explorer.desktop"

### remove backup of /etc/X11/xorg.conf
rm -f /etc/X11/xorg.conf.ori 2>/dev/null
rm -f /etc/X11/xorg.conf.backup 2>/dev/null

### remove unused dirs in /lib/modules
ls /lib/modules/ | grep -v $KERNEL | while read mod_dir; do
    rpm -qf --quiet /lib/modules/$mod_dir
    if [ $? != "0" ]; then
	if [ $mod_dir != "" ]; then
	    cleaned_dir=/tmp/cleaned-$( date +%Y%m%d%H%M )
	    mkdir -p $cleaned_dir
            echo "Move dir /lib/modules/$mod_dir to $cleaned_dir"
	    mv -f /lib/modules/$mod_dir $cleaned_dir/
        fi
    fi
done

### move some unneeded files to /mini (not for LiveDVD and miniCD)
if [ ! $DVD ] && [ ! $MINI ]; then
    # to save disk space

    mkdir -p /mini

    # move some dirs in /usr/share/doc to /mini
    mkdir -p /mini/usr/share/doc
    mv /usr/share/doc/openafs-* /mini/usr/share/doc 2>/dev/null
    mv /usr/share/doc/gcc-*     /mini/usr/share/doc 2>/dev/null
    mv /usr/share/doc/pine-*     /mini/usr/share/doc 2>/dev/null
    mv /usr/share/doc/ntp-*     /mini/usr/share/doc 2>/dev/null

    # move zipped java source to /mini, if j2sdk is installed
    java_src=$( rpm -ql j2sdk 2>/dev/null | grep src.zip )
    [ -e "$java_src" ] && mv "$java_src" /mini/
fi

### remove /etc/rc.d/init.d/login (should only be on Mini LiveCD)
##  this will be obsolete soon.
rm -f /etc/rc.d/init.d/login


echo "done."
echo "--------------------------------------------"



###############################################################
# Modify files
###############################################################

echo "Modify files ..."

### remove AFS startup warning about cache
[ $PSI ] && sed  -i "/\!\!\!/d" /etc/init.d/afs

### disable umount of loop device during shutdown
#   this is done really dirty at the moment:
#    -> just replace "loop" with non existing device "lo_fake"

[ -e /etc/init.d/netfs ]     && sed -i "s|/loop/|/lo_fake/|g" /etc/init.d/netfs
[ -e /etc/init.d/autofs ]    && sed -i "s|/loop/|/lo_fake/|g" /etc/init.d/autofs
[ -e /etc/init.d/halt ]      && sed -i "s|/loop/|/lo_fake/|g" /etc/init.d/halt
[ -e /etc/init.d/functions ] && sed -i "s|/loop/|/lo_fake/|g" /etc/init.d/functions

# do not shuttdown loopback interface
sed -i "s|[^#]action \$\"Shutting down loopback interface:|\t#action \$\"Shutting down loopback interface:|" /etc/init.d/network

### copy new /etc/init.d/halt 
cp -a customize/sl${OS_RELEASE}/halt /etc/init.d/halt

### in /etc/rc.d/rc.sysinit
#   comment out 'initlog -c "fsck -T -a $rootdev $fsckoptions"' 
#   to disable fsck of root filesystem
sed -i "s|\tfsck -T -a \$rootdev|\tsleep 0; #fsck -T -a \$rootdev|" /etc/rc.d/rc.sysinit
sed -i "s|\tinitlog -c \"fsck -T -a \$rootdev|\tsleep 0; #initlog -c \"fsck -T -a \$rootdev|" /etc/rc.d/rc.sysinit
#   disable "Remounting root filesystem in read-write mode"
sed -i "s| action \$\"Remounting root filesystem|#action \$\"Remounting root filesystem|" /etc/rc.d/rc.sysinit

### start afs with option -memcache !
if [ -e /etc/sysconfig/afs ]; then
    if [ $PSI ]; then
	sed -i "s|^EXTRA_OPTIONS=.*|EXTRA_OPTIONS='-fakestat -memcache'|" /etc/sysconfig/afs
    else
	grep -q "\-fakestat \-memcache" /etc/sysconfig/afs
	if [ "$?" != "0" ]; then
	    sed -i "s|-fakestat|-fakestat -memcache|" /etc/sysconfig/afs
	fi
    fi
fi

### source /etc/sysconfig/cfengine
[ $PSI ] && . /etc/sysconfig/cfengine

### Set /etc/motd
LiveCD="LiveCD"
[ "$ARCH" = "x86_64" ] && LiveCD="LiveCD 64bit"
echo "Welcome to $LIVECD_OS ${LiveCD}" > /etc/motd
[ $PSI ] && echo "Welcome to PSI ${LiveCD} (${CLASS} ${SUBCLASS} SL${RELEASE})" > /etc/motd

### Set hostname to psi or slinux (not really necessary)
if [ $PSI ]; then
    HOSTNAME="psi"
    sed -i "s/hostname=.*/hostname=${HOSTNAME}.psi.ch/" /etc/ssmtp/ssmtp.conf
    sed -i "s/HOSTNAME=.*/HOSTNAME=${HOSTNAME}/" /etc/sysconfig/cfengine
else
    HOSTNAME="$DEFAULT_HOSTNAME"
fi

# change hostname
sed -i "s/HOSTNAME=.*/HOSTNAME=${HOSTNAME}/" /etc/sysconfig/network
sed -i "s/DHCP_HOSTNAME=.*/DHCP_HOSTNAME==${HOSTNAME}/" /etc/sysconfig/networking/devices/ifcfg-eth0 2>/dev/null

### Modify /etc/redhat-release
ADD=" - LiveCD"
grep -q "$ADD" /etc/redhat-release
if [ "$?" != "0" ]; then
    echo "$( cat /etc/redhat-release )${ADD}" > /etc/redhat-release
fi
[ $DVD ] && sed -i "s|CD|DVD|" /etc/redhat-release

### Make scratch
if [ $PSI ]; then
    rm -rf /home/scratch
    mkdir -p /home/scratch
    chmod 1777 /home/scratch
    rm -rf /scratch
    ln -s /home/scratch /scratch
else
    rm -rf /home/scratch
    rm -rf /scratch
    mkdir -p /scratch
    chmod 1777 /scratch
fi

### set default runlevel to $RUNLEVEL
if [ $RUNLEVEL ]; then
    sed -i "s/id:.:initdefault:/id:$RUNLEVEL:initdefault:/" /etc/inittab
fi

### edit /etc/sysconfig/desktop
if [ $DESKTOP ]; then
    sed -i "/^DESKTOP=.*/d" /etc/sysconfig/desktop 2&>/dev/null
    echo "DESKTOP=$DESKTOP" >> /etc/sysconfig/desktop
fi
if [ $DISPLAYMANAGER ]; then
    sed -i "/^DISPLAYMANAGER=.*/d" /etc/sysconfig/desktop 2&>/dev/null
    echo "DISPLAYMANAGER=$DISPLAYMANAGER" >> /etc/sysconfig/desktop
fi

### GDM login background
if [ -e /usr/share/gdm/themes/SL/background.png ]; then
    cp -a customize/sl${OS_RELEASE}/background.png /usr/share/gdm/themes/SL/background.png
fi

### KDE default background
if [ ! $PSI ]; then
    if [ -e /usr/share/backgrounds/images/default.png ]; then
	cp -a customize/sl${OS_RELEASE}/default.png /usr/share/backgrounds/images/default.png
    fi
fi

### KDE startup/exit sound
if [ -e /usr/share/config/knotify.eventsrc ]; then
    cp -a customize/sl/knotify.eventsrc /usr/share/config/knotify.eventsrc
    cp -a customize/sl/kmixrc /usr/share/config/kmixrc
fi

### KDE session manager; start at login
#   kmix, krandrtray
if [ -e /usr/share/config/ksmserverrc ]; then
    cp -a customize/sl/ksmserverrc /usr/share/config/ksmserverrc
fi    

### Configure SELinux
if [ $SELINUX ]; then
    if [ -e /etc/selinux/config ]; then
	sed -i "s|^SELINUX=.*|SELINUX=$SELINUX|" /etc/selinux/config
    fi
fi

### Do not like jumping CD icon when starting autorun.desktop
if [ -e /etc/skel/.kde/Autostart/Autorun.desktop ]; then
    grep -q "StartupNotify=false" /etc/skel/.kde/Autostart/Autorun.desktop
    if [ "$?" != "0" ]; then
	echo "StartupNotify=false" >> /etc/skel/.kde/Autostart/Autorun.desktop
    fi
fi

echo "done."
echo "--------------------------------------------"



###############################################################
# Add-ons
###############################################################

echo "Add-ons ..."

### System icon on desktop
if [ -d /usr/share/apps/kdesktop/DesktopLinks ]; then
    cp -a customize/System.desktop /usr/share/apps/kdesktop/DesktopLinks/
fi

### files for PSI User, will be copied during bootup to /home/$LOCALUSER/
if [ $PSI ]; then
    rm -rf /usr/share/$LOCALUSER
    cp -a customize/$LOCALUSER /usr/share/
fi

### psi-menu, psi-scanvirus
if [ $PSI ]; then
    cp -a customize/psi/psi-menu /usr/bin/
    cp -a customize/psi/psi-scanvirus /usr/bin/
    [ -d /usr/local/uvscan ] && cp -a customize/psi/update-dat /usr/local/uvscan/
    [ -x /usr/bin/freshclam ] && cp -a customize/psi/psi-freshclam /usr/bin/
fi

### script to install LiveCD on local harddisk
cp -a customize/livecd-install  /usr/bin/

### livecd-mkinitrd (used by livecd-install)
if [ -e customize/sl${OS_RELEASE}/livecd-mkinitrd ]; then
    cp -a customize/sl${OS_RELEASE}/livecd-mkinitrd /usr/sbin/
else
    cp -a /sbin/mkinitrd /usr/sbin/livecd-mkinitrd
fi


echo "done."
echo "--------------------------------------------"



###############################################################
# Create special files
###############################################################

echo "Create special files ..."

###############################################################
# /etc/rc.d/init.d/kudzu-auto
### Noninteractive HW detection and configuration

cp -a customize/kudzu-auto /etc/init.d/kudzu-auto
chmod +x /etc/rc.d/init.d/kudzu-auto
ln -sf /etc/rc.d/init.d/kudzu-auto /etc/rc.d/rc5.d/S04kudzu-auto
ln -sf /etc/rc.d/init.d/kudzu-auto /etc/rc.d/rc3.d/S04kudzu-auto


###############################################################
# /etc/rc.d/init.d/runveryfirst
### Fix some things during bootup - run VERY first
# runveryfirst will run at the begining of /etc/rc.d/rc.sysinit

cp -a customize/runveryfirst /etc/init.d/runveryfirst
chmod +x /etc/rc.d/init.d/runveryfirst

# execute runveryfirst just before "Initialize hardware"
grep -q runveryfirst /etc/rc.d/rc.sysinit
if [ "$?" != "0" ]; then
    sed -i -e "/^# Initialize hardware/a\/etc\/init.d\/runveryfirst" /etc/rc.d/rc.sysinit
fi


###############################################################
# /etc/rc.d/init.d/runfirst
### Fix some things during bootup - run first
# runfirst will run at the end of /etc/rc.d/rc.sysinit

cp -a customize/runfirst /etc/init.d/runfirst
chmod +x /etc/rc.d/init.d/runfirst

sysinit_line="/etc/rc.d/init.d/runfirst"
grep -q "$sysinit_line" /etc/rc.d/rc.sysinit
if [ "$?" != "0" ]; then
    echo "$sysinit_line" >> /etc/rc.d/rc.sysinit
    echo >> /etc/rc.d/rc.sysinit
fi


###############################################################
# /etc/rc.d/init.d/runlast
### Fix some things during bootup - run last

cp -a customize/runlast /etc/init.d/runlast
chmod +x /etc/rc.d/init.d/runlast

### Add /etc/rc.d/init.d/runlast to rc.local
LINE=/etc/rc.d/init.d/runlast
grep -q $LINE /etc/rc.d/rc.local
if [ "$?" != "0" ]; then
    # add line
    echo "" >> /etc/rc.d/rc.local
    echo $LINE >> /etc/rc.d/rc.local
    echo "" >> /etc/rc.d/rc.local    
fi


###############################################################
# /usr/bin/save-localdata
### stores data on a usbstick
cp -a customize/save-localdata /usr/bin/save-localdata
chmod +x /usr/bin/save-localdata

# add /usr/bin/save-localdata to /etc/sudoers
grep -q "save-localdata" /etc/sudoers 2>/dev/null
if [ "$?" != "0" ]; then
    echo "$LOCALUSER ALL = NOPASSWD: /usr/bin/save-localdata" >> /etc/sudoers
fi

# create menu entry
cp -a customize/save-localdata.desktop /usr/share/applications/


###############################################################
# /usr/bin/set-volume
### unmute all mixers and set volumes
cp -a customize/set-volume /usr/bin/set-volume
chmod +x /usr/bin/set-volume


###############################################################
# /etc/sysconfig/networking/devices/ifcfg-eth0
# /etc/sysconfig/networking/devices/ifcfg-eth1

for iface in eth0 eth1; do 

    # remove it first
    rm -f /etc/sysconfig/networking/devices/ifcfg-${iface} 2>/dev/null
    rm -f /etc/sysconfig/networking/profiles/default/ifcfg-${iface} 2>/dev/null
    rm -f /etc/sysconfig/network-scripts/ifcfg-${iface} 2>/dev/null

    # create it, if we have a sample
    if [ -e customize/sl${OS_RELEASE}/ifcfg-${iface} ]; then
	cp -a customize/sl${OS_RELEASE}/ifcfg-${iface} /etc/sysconfig/networking/devices/ifcfg-${iface}
        # make hard links
	cp -lf /etc/sysconfig/networking/devices/ifcfg-${iface} /etc/sysconfig/networking/profiles/default/
	cp -lf /etc/sysconfig/networking/devices/ifcfg-${iface} /etc/sysconfig/network-scripts/
    fi
done


###############################################################
# /etc/profile.d/setsysfont.sh
### setsysfont 
cat > /etc/profile.d/setsysfont.sh <<EOF
# setsysfont once
if [ ! -e /tmp/.sysfont_has_been_set ]; then
    touch /tmp/.sysfont_has_been_set
    /bin/setfont 2>/dev/null
    /sbin/setsysfont 2>/dev/null
fi
EOF
chmod 755 /etc/profile.d/setsysfont.sh


###############################################################
# /etc/profile.d/setsysfont.csh
### setsysfont 
cat > /etc/profile.d/setsysfont.csh <<EOF
# setsysfont once
if ( ! -e /tmp/.sysfont_has_been_set ) then
    touch /tmp/.sysfont_has_been_set
    /bin/setfont 2>/dev/null
    /sbin/setsysfont 2>/dev/null
endif
EOF
chmod 755 /etc/profile.d/setsysfont.csh


###############################################################
# /etc/cron.d/psi
### PSI specific cronjobs

if [ $PSI ]; then
    cp -a customize/psi/cron_psi /etc/cron.d/psi
    chmod +x /etc/cron.d/psi
fi

echo "done."
echo "--------------------------------------------"



###############################################################
# Configure services
###############################################################

echo "Configure services ..."

### services off

if [ $PSI ]; then
    chkconfig cfenvd off 2>/dev/null
    chkconfig cfexecd off 2>/dev/null
    chkconfig cfservd off 2>/dev/null
fi
if [ ! "$SERVICES_OFF" = "" ]; then
    for service in $SERVICES_OFF; do
	chkconfig $service off 2>/dev/null
    done
fi
# we do kudzu-auto
chkconfig kudzu off 


### services on

if [ $PSI ]; then
    chkconfig vpnclient_init on 2>/dev/null
fi
if [ ! "$SERVICES_ON" = "" ]; then
    for service in $SERVICES_ON; do
	chkconfig $service on 2>/dev/null
    done
fi

echo "done."
echo "--------------------------------------------"


###############################################################
# Empty files
###############################################################

echo "Empty files ..."

### /etc/security/users
if [ $PSI ]; then
    rm -f /etc/security/users
    touch /etc/security/users
fi

### Files to empty
FILES_TOUCH="/etc/sysconfig/hwconf \
             /etc/resolv.conf \
             /etc/adjtime \
             /etc/modprobe.conf \
             /etc/dhclient-eth0.conf"

for file in $FILES_TOUCH; do
    rm -rf $file
    touch $file
done

echo "done."
echo "--------------------------------------------"


###############################################################
# Update locate db, prelink, makewhatis
###############################################################

### run slocate
if [ -x /usr/bin/updatedb ]; then
    echo "Run updatedb..."
    . /etc/updatedb.conf 2>/dev/null
    rpm -q mlocate >/dev/null
    if [ "$?" = "0" ]; then
	/usr/bin/updatedb -e "/media /sfs /tmp /boot /livecd /home /net"
    else
	/usr/bin/updatedb -e /media,/tmp,/boot,/livecd,/home,/net
    fi
    echo "done."
fi

### run prelink
if [ -x /etc/cron.daily/prelink ]; then
    echo "Run prelink..."
    /etc/cron.daily/prelink
    echo "done."
fi
if [ -x /etc/cron_backup/prelink ]; then
    echo "Run prelink..."
    /etc/cron_backup/prelink
    echo "done."
fi

### clean prelink log
rm -f /var/log/prelink/prelink.log 2>/dev/null
rm -f /var/log/prelink.log 2>/dev/null

### run makewhatis
if [ -x /usr/bin/makewhatis ]; then
    echo "Run makewhatis..."
    makewhatis -u -w
fi

echo "done."
echo "--------------------------------------------"

###############################################################
