#!/bin/bash
#
###############################################################
#
# Main script to build LiveCD
# 
# will execute
# - ./customize-livecd.sh
# - ./mini-livecd.sh  (if -mini set)
# - ./linux-live.sl/runme.sh
# - ./restore-system.sh
#
# will take the configuration from
# - ./livecd.conf
#
# Urs Beyerle, PSI
#
###############################################################


###############################################################
### Functions
###############################################################

function usage() {

   ## Usage
   # ----------------------------------------------------------

   cat <<EOF

  Options:

    -h          print this screen
    -sl4        build SL4 LiveCD/DVD
    -sl5        build SL5 LiveCD/DVD

  Optional Options:

    -psi        customize for PSI LiveCD
    -mini       build a MINI-CD (not well tested)
    -dvd        build a LiveDVD
    
  Additionally Options for MINI-CD:

    -nomove:    do NOT move to /mini to save diskspace 
    -rootlogin: directly login as root

  Configuration file:

    See livecd.conf for more configuration options !!


EOF

exit

}

###############################################################
### Definitions and settings
###############################################################

### read options from command-line
OPTIONS=$@
OS_RELEASE=""

while [ $# -gt 0 ]; do

    case "$1" in
       -h)
            usage; exit;;
       -psi)
            PSI="-psi"; shift; continue;;
       -sl4)
            SL="-sl"; export OS_RELEASE=4; shift; continue;;
       -sl5)
            SL="-sl"; export OS_RELEASE=5; shift; continue;;
       -mini)
            MINI="-mini"; shift; continue;;
       -nomove)
            NOMOVE="-nomove"; shift; continue;;
       -rootlogin)
            ROOTLOGIN="-rootlogin"; shift; continue;;
       -dvd)
            DVD="-dvd"; shift; continue;;
       *)
            usage;;
    esac

done


### source livecd.conf
. livecd.conf

### test input
[ ! $SL ] && usage 

### do not run without psi option on a PSI installation
if [ -e /etc/sysconfig/cfengine ] && [ ! $PSI ]; then
    echo "I guess this is a PSI installation, please use option '-psi'"; echo
    exit
fi

### check if I run inside my directory
if [ ! -x $( basename $0 ) ]; then
    echo "Please run $( basename $0 ) within its directory"
    exit 1
fi

### add extra boot options
BOOT_OPTIONS="$BOOT_OPTIONS $EXTRA_BOOT_OPTIONS"

### add option "psi" for PSI
[ $PSI ] && BOOT_OPTIONS="psi $BOOT_OPTIONS"

### define ARCH
ARCH=$( /bin/arch )
[ "$ARCH" != "x86_64" ] && ARCH=i686

### define RELEASE string
RELEASE="my"
[ -e /etc/redhat-release ] && RELEASE=$( cat /etc/redhat-release )

### write script version to /etc/livecd-release
SCRIPT_VERSION=$( cat version 2>/dev/null )
echo $SCRIPT_VERSION > /etc/livecd-release

### Check for SMP kernel and set SMP variable
#   if you change SMP="s", you have also to change isolinux.cfg!
#   SMP can only be one character in lenght!
SMP=""
[ -e /boot/vmlinuz-${KERNEL}smp ] && export SMP="s"



###############################################################
### Build LiveCD
###############################################################

### display summary
### -----------------------------------------------------------

echo; echo "--------------------------------------------"
if [ $DVD ]; then 
    echo "Build of LiveDVD started"
else
    echo "Build of LiveCD started"
fi
echo "Script version:      $SCRIPT_VERSION"
echo "Kernel version:      $KERNEL"
[ $SMP ] && echo "SMP Kernel version:  ${KERNEL}smp"
echo "--------------------------------------------"

[ $PSI ]  && echo "**** Build for PSI ****"
[ "$OS_RELEASE" = "4" ]   && echo "**** Build for SL4 ****"
[ "$OS_RELEASE" = "5" ]   && echo "**** Build for SL5 ****"
[ $MINI ] && echo "**** Build for MINI-CD ****"
echo "--------------------------------------------"



### download livecd web page (for documentation)
### -----------------------------------------------------------
echo "Try to download latest livecd documentation"

rm -rf /tmp/doc
mkdir -p /tmp/doc
wget --timeout=3 --quiet -nH --mirror -P /tmp/doc http://linux.web.psi.ch/livecd/
wget --timeout=3 --quiet -nH --mirror -P /tmp/doc http://linux.web.psi.ch/livecd/layout.css
if [ -d /tmp/doc/livecd ]; then
    echo "done."
else
    echo "download failed - not critical ;-)"
fi



### clean up build script directory
### -----------------------------------------------------------
echo "--------------------------------------------"
echo "Remove all *~ files in $( pwd )"
find . | grep "~$" | while read f; do rm -f "$f"; done
echo "done."
echo "--------------------------------------------"



### Run customize-livecd.sh
### -----------------------------------------------------------
echo
echo "--------------------------------------------"
echo "Run ./customize-livecd.sh $PSI $DVD"
echo "--------------------------------------------"
./customize-livecd.sh $PSI $DVD $MINI



### Run mini-livecd.sh
### -----------------------------------------------------------
if [ $MINI ]; then
    echo "--------------------------------------------"
    echo "Run ./mini-livecd.sh $PSI $ROOTLOGIN $NOMOVE"
    echo "--------------------------------------------"
    ./mini-livecd.sh $PSI $ROOTLOGIN $NOMOVE
fi



### Create /usr/share/doc/livecd
### -----------------------------------------------------------
if [ -d /tmp/doc/livecd ]; then
    echo
    echo "--------------------------------------------"
    echo "Create /usr/share/doc/livecd"
    echo "--------------------------------------------"
    mkdir -p /usr/share/doc/HTML
    cp -a customize/HTML/index.html /usr/share/doc/HTML/index.html    
    rm -rf /usr/share/doc/livecd
    cp -a /tmp/doc/livecd /usr/share/doc/
    echo "done."
    echo
fi



### Prepare files in linux-live.sl directory 
### -----------------------------------------------------------
echo
echo "--------------------------------------------"
echo "cd linux-live.sl"
echo "--------------------------------------------"

cd linux-live.sl

echo "Set kernel boot options in cd-root/isolinux.cfg"

## for lable linux
sed -i "s|append l initrd=boot/initrd.gz init=linuxrc .*|append l initrd=boot/initrd.gz init=linuxrc $BOOT_OPTIONS|" cd-root/isolinux.cfg

## for lable linuxsmp
sed -i "s|append l initrd=boot/initrd${SMP}.gz init=linuxrc .*|append l initrd=boot/initrd${SMP}.gz init=linuxrc $BOOT_OPTIONS|" cd-root/isolinux.cfg

## for lable failsafe
sed -i "s|append f initrd=boot/initrd.gz init=linuxrc .*|append f initrd=boot/initrd.gz init=linuxrc $BOOT_OPTIONS $FAILSAFE_BOOT_OPTIONS|" cd-root/isolinux.cfg

## Set Welcome ...
echo "Set 'Welcome ... to' in splash.cfg"
sed -i "s|DVD|CD|" cd-root/boot/splash.cfg
if [ $PSI ]; then
    sed -i "s|Welcome to.*|Welcome to PSI $LIVECD_OS LiveCD|" cd-root/boot/splash.cfg
else
    sed -i "s|Welcome to.*|Welcome to $RELEASE|" cd-root/boot/splash.cfg
fi

## Set LiveCD / LiveCD 64bit
sed -i "s|LiveCD 64bit|LiveCD|" cd-root/boot/splash.cfg
[ "$ARCH" = "x86_64" ] && sed -i "s|LiveCD|LiveCD 64bit|" cd-root/boot/splash.cfg

## Set DVD or CD
[ $DVD ] && sed -i "s|CD|DVD|" cd-root/boot/splash.cfg



### Run runme.sh
### -----------------------------------------------------------
echo
echo "--------------------------------------------"
echo "Run ./runme.sh"
echo "--------------------------------------------"
./runme.sh



### Run restore-system.sh
### -----------------------------------------------------------
echo
echo "--------------------------------------------"
echo "Now fix things to make this system bootable"
echo "--------------------------------------------"
cd ..
./restore-system.sh $PSI



### End of LiveCD build
### -----------------------------------------------------------
echo "--------------------------------------------"
echo "End of Build LiveCD" 
echo "See /tmp for the ISO image"
echo "--------------------------------------------"
