#!/bin/bash
#
###############################################################
#
# Restore the system to a usable and bootable installation
#
# Urs Beyerle, PSI
#
###############################################################

# source livecd.conf
. livecd.conf

###############################################################

function usage() {

   ## Usage
   # ----------------------------------------------------------

   cat <<EOF

   Options:

    -h:       print this screen
    -psi:     customize for PSI Live CD

EOF

}

###############################################################

### read options from command-line
PSI=""
while [ $# -gt 0 ]; do

    case "$1" in
       -h)
            usage; exit;;
       -psi)
            PSI=true; shift; continue;;
       *)
            usage; exit;;
    esac

done


###############################################################

### check if I run inside my directory
if [ ! -x $( basename $0 ) ]; then
    echo "Please run $( basename $0 ) within its directory"
    exit 1
fi

LIVECD_DIR=$( pwd )

### restore /etc/rc.d/rc.sysinit
cp /etc/rc.d/rc.sysinit.ori /etc/rc.d/rc.sysinit

### enable ssh again
chkconfig sshd on 2>/dev/null

### create link to liblinuxlive
mkdir -p /livecd/live
rm -f /livecd/live/liblinuxlive
ln -s $LIVECD_DIR/linux-live.sl/initrd/liblinuxlive /livecd/live/liblinuxlive

### restore /etc/resolv.conf
mv -f /etc/resolv.conf.ori /etc/resolv.conf

### move /etc/yum.repos.d, it will interfere with our yum.conf.psi
if [ -d /etc/yum.repos.d ]; then
    rm -rf /etc/yum.repos.d.ori
    mv -f /etc/yum.repos.d /etc/yum.repos.d.ori
fi

### restore folders from /mini
if [ -f /mini/usr/share/info/bash.info.gz ]; then
    ./mini-livecd.sh -restore
fi

### restore cronjobs
mv /etc/cron_backup/sysstat /etc/cron.d/ 2>/dev/null
mv /etc/cron_backup/00-makewhatis.cron.weekly /etc/cron.weekly/00-makewhatis.cron 2>/dev/null
mv /etc/cron_backup/* /etc/cron.daily/

### set root password again
[ "$SET_ROOTPWD" = "yes" ] && passwd
[ "$SET_ROOTPWD" != "yes" ] && echo "Please note: root password is unset, run passwd to set it again."
