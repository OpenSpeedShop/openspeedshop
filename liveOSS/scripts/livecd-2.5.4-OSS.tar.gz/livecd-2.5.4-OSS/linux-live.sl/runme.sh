#!/bin/bash
#
# run this script to create a LiveCD in /tmp/livecd.iso
# Your kernel image has to be in $ROOT/boot/vmlinuz or $ROOT/vmlinuz
# 
# Urs Beyerle, PSI:
# - add x86_64 support
# - add support to build for UP and SMP kernel
#   SMP kernel is added to LiveCD, if variable $SMP is set
# - copy /boot/System.map-* and /boot/config-* to $CDDATA/boot
#   copy /boot/grub/splash.xpm.gz to $CDDATA/boot/grub
#   copy /boot/message* $CDDATA/boot/
#   copy /boot/symvers-* $CDDATA/boot/
#   all needed for install LiveCD in local harddisk
# - config no longer sourced, we take ../livecd.conf
#

export LANG=C

ARCH=$( /bin/arch )
[ "$ARCH" != "x86_64" ] && ARCH=i686

# export PATH=.:./tools:../tools:/usr/sbin:/usr/bin:/sbin:/bin:/
export PATH=/usr/sbin:/usr/bin:/sbin:/bin:/:.:./tools:../tools

CHANGEDIR="`dirname \`readlink -f $0\``"
echo "Changing current directory to $CHANGEDIR"
cd $CHANGEDIR

. liblinuxlive || exit 1
# . config || exit 1
. ../livecd.conf || exit 1

./install $ROOT

VMLINUZ=$ROOT/boot/vmlinuz
if [ -L "$VMLINUZ" ]; then VMLINUZ=`readlink -f $VMLINUZ`; fi
if [ "`ls $VMLINUZ 2>/dev/null`" = "" ]; then echo "cannot find $VMLINUZ"; exit 1; fi

if [ $SMP ]; then
    VMLINUZ_SMP=$ROOT/boot/vmlinuz${SMP}
    if [ -L "$VMLINUZ_SMP" ]; then VMLINUZ_SMP=`readlink -f $VMLINUZ_SMP`; fi
    if [ "`ls $VMLINUZ_SMP 2>/dev/null`" = "" ]; then echo "cannot find $VMLINUZ_SMP"; exit 1; fi
fi

header "Creating LiveCD from your Linux"

mkdir -p $CDDATA/base
mkdir -p $CDDATA/modules
mkdir -p $CDDATA/optional
mkdir -p $CDDATA/rootcopy

echo "copying livecd.conf to $CDDATA"
cp -a ../livecd.conf $CDDATA/

echo "copying cd-root to $CDDATA"
cp -R cd-root/* $CDDATA
if [ ! $SMP ]; then
    # delete line with "SMP kernel" in boot/splash.cfg
    sed -i "/SMP kernel/d" $CDDATA/boot/splash.cfg
    # delete 'or "smp" ' in  boot/help*.txt
    sed -i 's/or "smp" //' $CDDATA/boot/help*.txt
fi

# cp -R tools $CDDATA
cp -R info/* $CDDATA

# copy splash.xpm.gz to LiveCD
mkdir -p $CDDATA/boot/grub
cp -a $ROOT/boot/grub/splash.xpm.gz $CDDATA/boot/grub/

# copy kernel(s) to LiveCD
echo "using kernel from $VMLINUZ"
echo "and kernel modules from /lib/modules/$KERNEL"
cp -a $VMLINUZ $CDDATA/boot/vmlinuz
if [ $SMP ]; then 
    echo "using kernel from $VMLINUZ_SMP"
    echo "and kernel modules from /lib/modules/${KERNEL}smp"
    cp -a $VMLINUZ_SMP $CDDATA/boot/vmlinuz${SMP}
fi

# copy System.map, config, etc. to LiveCD /boot
cp -a $ROOT/boot/System.map-* $CDDATA/boot/
cp -a $ROOT/boot/config-*  $CDDATA/boot/
cp -a $ROOT/boot/message*  $CDDATA/boot/
cp -a $ROOT/boot/symvers-* $CDDATA/boot/ 2>/dev/null

BUILD_KERNELS="$KERNEL"
[ $SMP ] && BUILD_KERNELS="$BUILD_KERNELS ${KERNEL}smp"

echo "creating initrd image..."

for BUILD_KERNEL in $BUILD_KERNELS; do

    cd initrd
    ./initrd_create $BUILD_KERNEL
    if [ "$?" -ne 0 ]; then exit; fi
    cd ..
    if [ "$BUILD_KERNEL" = "$KERNEL" ]; then
	echo "add initrd.gz for kernel $BUILD_KERNEL"
	cp initrd/$INITRDIMG.gz $CDDATA/boot/initrd.gz        # UP Kernel
    else
	echo "add initrd${SMP}.gz for kernel $BUILD_KERNEL"
	cp initrd/$INITRDIMG.gz $CDDATA/boot/initrd${SMP}.gz  # SMP Kernel
    fi
    rm initrd/$INITRDIMG.gz

done

echo "creating compressed images..."

# home not longer in the list, will be created on the fly
# opt -> /usr/opt
#
if [ "$ARCH" = "x86_64" ]; then
    dirs="bin etc lib lib64 root usr sbin var"
else
    dirs="bin etc lib root usr sbin var"
fi

for dir in $dirs; do
    if [ -d $ROOT/$dir ]; then
      echo "base/$dir.mo"
      create_module $ROOT/$dir $CDDATA/base/$dir.mo -keep-as-directory
      if [ $? -ne 0 ]; then exit; fi
    fi
done

# remove any .svn folders from the CD
find $CDDATA -type d -name .svn -exec rm -f {} \;

echo "creating LiveCD ISO image..."
cd $CDDATA
./make_iso.sh /tmp/livecd.iso

cd /tmp
header "Your ISO is created in /tmp/livecd.iso"
